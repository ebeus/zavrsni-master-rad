//Driverlib
#include <ti/devices/msp432p4xx/driverlib/driverlib.h>
#include <ti/grlib/grlib.h>
#include <ti/devices/msp432p4xx/inc/msp.h>


#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <stdio.h>

#define ADC_CYCLES_TOTAL_NO 239
#define ADC_CYCLES_CONVERSION_NO 19
#define TIME_CONSTANT (((float)(ADC_CYCLES_TOTAL_NO+1))/24000000.0f)*3.0
#define MULTIPLIER TIME_CONSTANT/2.0
#define SAMPLES_FOR_VECTOR 10000
#define EXPERIMENT_DURATION 1



int_fast32_t avg_x = 0;
int_fast32_t avg_y = 0;
int_fast32_t avg_z = 0;

uint_fast32_t val_x=0;
uint_fast32_t val_y=0;
uint_fast32_t val_z=0;

uint_fast32_t val_x_prev=0;
uint_fast32_t val_y_prev=0;
uint_fast32_t val_z_prev=0;

uint_fast32_t i = 0;
uint_fast32_t start_time = 0;
uint_fast32_t end_time = 0;
uint_fast32_t exec_time = 0;
uint_fast32_t avg_cycles = 0;

uint_fast32_t broj_prekida = 0;
uint_fast32_t vrijeme = 0;

float results[3] = {0, 0, 0};
float velocity[3] = {0, 0, 0};
float distance[3] = {0, 0, 0};
float results_prev[3] = {0, 0, 0};
float velocity_prev[3] = {0, 0, 0};
float distance_prev[3] = {0, 0, 0};


void InitializeVector();
/*Konfiguracija Up nacina rada za TimerA
 *---------- P A R A M E T R I ---------
 *      Izvor signala sata - SMCLK - TIMER_A_CLOCKSOURCE_SMCLK
 *      Djelilac sata - TIMER_A_CLOCKSOURCE_DIVIDER_1
 *      Broj ciklusa sata nakon kojeg se timer restartuje, 16-bitna vrijednost od 0 do X
 *      Omogucavanje prekida
 * */
const Timer_A_UpModeConfig upModeConfig =
{
        TIMER_A_CLOCKSOURCE_SMCLK,
        TIMER_A_CLOCKSOURCE_DIVIDER_1,
        ADC_CYCLES_TOTAL_NO,
        TIMER_A_TAIE_INTERRUPT_DISABLE,
        TIMER_A_CCIE_CCR0_INTERRUPT_DISABLE,
        TIMER_A_DO_CLEAR
};

/* Konfigurisanje Capture nacina rada za TimerA
 * ---------- P A R A M E T R I ---------
 *      Registar koji koristimo za Capture/Compare - CCR1
 *      Onemogucavanje prekida
 *      Set/Reset izlaz
 *      Broj ciklusa nakon kojih TimerA daje na izlazu logicku jedinicu u ovom nacinu rada - Y
 * */
const Timer_A_CompareModeConfig compareConfig =
{
        TIMER_A_CAPTURECOMPARE_REGISTER_1,
        TIMER_A_CAPTURECOMPARE_INTERRUPT_DISABLE,
        TIMER_A_OUTPUTMODE_SET_RESET,
        ADC_CYCLES_CONVERSION_NO
};


int main(void)
{
    /* Zaustavljanje WDT  */
    MAP_WDT_A_holdTimer();

    /* Set the core voltage level to VCORE1 */
    MAP_PCM_setCoreVoltageLevel(PCM_VCORE1);

    /* Set 2 flash wait states for Flash bank 0 and 1*/
    MAP_FlashCtl_setWaitState(FLASH_BANK0, 2);
    MAP_FlashCtl_setWaitState(FLASH_BANK1, 2);

    //Postavljanje DCO frekvencije
    CS_setDCOCenteredFrequency(CS_DCO_FREQUENCY_48);
    //Izvor satnog signala za druge satove sa djeliocem
    CS_initClockSignal(CS_MCLK, CS_DCOCLK_SELECT, CS_CLOCK_DIVIDER_1);
    CS_initClockSignal(CS_HSMCLK, CS_DCOCLK_SELECT, CS_CLOCK_DIVIDER_1);
    CS_initClockSignal(CS_SMCLK, CS_DCOCLK_SELECT, CS_CLOCK_DIVIDER_1);
    CS_initClockSignal(CS_ACLK, CS_REFOCLK_SELECT, CS_CLOCK_DIVIDER_1);


    //Postavljanje LazyStacking-a koji omogucava da se sadrzaj FP registara ne sprema prilikom promjene konteksta
    //Ovo omogucava da smanjimo kasnjenje prilikom prebacivanja na rutinu za obradu prekida
    FPU_enableLazyStacking();

    /*Konfiguracija dioda za signalizaciju
    Zelena oznacava da sistem racuna distancu
    Crvena u ostalim slucajevima
    Pin 6 RED LED, 4 GREEN LED PORT2*/
    GPIO_setAsOutputPin(GPIO_PORT_P2, GPIO_PIN6 | GPIO_PIN4);

    //RED LED ON - GREEN OFF
    GPIO_setOutputLowOnPin(GPIO_PORT_P2, GPIO_PIN4);
    GPIO_setOutputHighOnPin(GPIO_PORT_P2, GPIO_PIN6);

    /*  Konfiguracija TimerA za Up nacin rada
        Parametri:
            - Timer: TIMER_A0_BASE
            - Konfiguracija - struktura*/
    Timer_A_configureUpMode(TIMER_A0_BASE, &upModeConfig);

    /*  Konfiguracija TimerA za Compare nacin rada
        Parametri:
            - Timer: TIMER_A0_BASE
            - Konfiguracija - struktura*/
    Timer_A_initCompare(TIMER_A0_BASE, &compareConfig);

    //Omogucavanje ADC14 modula
    ADC14_enableModule();
    ADC14_initModule(ADC_CLOCKSOURCE_ADCOSC, ADC_PREDIVIDER_1, ADC_DIVIDER_1,
            0);

    /* PODESAVANJE ADC14 MODULA
     * ADC14_CTL0_ON - Modul ukljucen
     * ADC14_CTL0_MSC - Multiple Sample and Convert nacin rada, omogucava da iduca konverzija starta kada trenutna zavrsi
     * ADC14_CTL0_SHS_1 - Konverzija ce biti vodjena Timerom
     * ADC14_CTL0_CONSEQ_3 - Kontinualna konverzija vise kanala
     * */
    ADC14->CTL0 = ADC14_CTL0_ON |
            ADC14_CTL0_MSC |
            ADC14_CTL0_SHS_1 |
            ADC14_CTL0_CONSEQ_3;

    //Konfigurisanje referentnih napona, ulaznih pinova i oznacavanje kraja sekvence
    ADC14->MCTL[0] = ADC14_MCTLN_VRSEL_0 | ADC_INPUT_A14;
    ADC14->MCTL[1] = ADC14_MCTLN_VRSEL_0 | ADC_INPUT_A13;
    ADC14->MCTL[2] = ADC14_MCTLN_VRSEL_0 | ADC_INPUT_A11 | ADC14_MCTLN_EOS ;

    //Reyolucija 14-bita, bez ustede energije, koji ogranicava brzinu na 200 ksps
    ADC14->CTL1 |= ADC14_CTL1_RES_3 | ADC14_CTL1_PWRMD_0;

    //Inicijalizacija vektora koji oduzimamo od ocitanih vrijednosti
    InitializeVector();

    //Omogucavanje ADC14 Modula
    ADC14_enableModule();

    //Postavljanje prioriteta prekida
    Interrupt_setPriority(ADC_INT2, 1);
    Interrupt_setPriority(INT_T32_INT2, 2);

    //Omogucavanje interne komponente za debugging
    CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
    ITM->LAR =  0xC5ACCE55;
    DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;

    //Omogucavanje prekida za ADC14MEM2
    ADC14_enableInterrupt(ADC_INT2);
    //Omogucavanje konverzija
    ADC14_enableConversion();

    //Omogucavanje prekida za ADC14 modul
    Interrupt_enableInterrupt(INT_ADC14);
    //Omogucavanje definisanih prekida
    Interrupt_enableMaster();

    /*
     *
     *Podesavanje Timer32 za odbrojavanje
     *Nakon sto odbrojavanje zavrsi poziva se interrupt rutina
     *
     * */

    //Inicijalizacija Timer32 modula
    Timer32_initModule(TIMER32_1_BASE, TIMER32_PRESCALER_1, TIMER32_32BIT, TIMER32_CONTROL_ONESHOT);
    //Postavljanje brojaca Timer-a 32
    Timer32_setCount(TIMER32_1_BASE, SystemCoreClock*EXPERIMENT_DURATION);
    //Omogucavanje prekida za Timer32
    Interrupt_enableInterrupt(INT_T32_INT2);

    //LED indikatori za start
    GPIO_setOutputLowOnPin(GPIO_PORT_P2, GPIO_PIN6);
    GPIO_setOutputHighOnPin(GPIO_PORT_P2, GPIO_PIN4);

    //Pokretanje timer32 za odbrojavanje i timerA za konverziju
    Timer32_startTimer(TIMER32_1_BASE, false);
    Timer_A_startCounter(TIMER_A0_BASE, TIMER_A_UP_MODE);

    while (1)
    {
    }
}

/*
 * Racunaje prosjecnih vrijednosti ubrzanja u stanju mirovanja, da bi se
 * oduzela gravitaciona komponenta
 */
void InitializeVector() {
    //Omogucavanje konverzije
    ADC14_enableConversion();
    //Pokretanje brojaca Timer-a A
    Timer_A_startCounter(TIMER_A0_BASE, TIMER_A_UP_MODE);

    //Uzimanje SAMPLES_FOR_VECTOR broja uzoraka
    for(i = 0; i < SAMPLES_FOR_VECTOR; i++) {
        while(!(ADC14->IFGR0 & ADC14_IFGR0_IFG2));
            avg_x += ADC14->MEM[0];
            avg_y += ADC14->MEM[1];
            avg_z += ADC14->MEM[2];

    }

    //Onemogucavanje konverzije
    ADC14_disableConversion();
    //Onemogucavanje modula
    ADC14_disableModule();
    //Zaustavljanje timer-a A
    Timer_A_stopTimer(TIMER_A0_BASE);

    //Racunanje prosjeka
    avg_x = avg_x/SAMPLES_FOR_VECTOR - 8192;
    avg_y = avg_y/SAMPLES_FOR_VECTOR - 8192;
    avg_z = avg_z/SAMPLES_FOR_VECTOR - 8192;
}

void ADC14_IRQHandler(void)
{
    //Broj ciklusa na pocetku interrupt handler-a
    start_time = DWT->CYCCNT;

    //brojac prekida
    broj_prekida++;

    //Ocitanje vrijednosti i korekcija
    val_x = ADC14->MEM[0] - avg_x;
    val_y = ADC14->MEM[1] - avg_y;
    val_z = ADC14->MEM[2] - avg_z;

    //Pretvaranje ubrzanja u m/s^2
    results[0] = ((float) val_x) * (0.00299376675 - 24.525);
    results[1] = ((float) val_y) * (0.00299376675 - 24.525);
    results[2] = ((float) val_z) * (0.00299376675 - 24.525);

    //Racunanje brzine
    velocity[0] = velocity_prev[0] + MULTIPLIER * (results[0] + results_prev[0]);
    velocity[1] = velocity_prev[1] + MULTIPLIER * (results[1] + results_prev[1]);
    velocity[2] = velocity_prev[2] + MULTIPLIER * (results[2] + results_prev[2]);

    //Racunaje puta
    distance[0] = distance_prev[0] + MULTIPLIER * (velocity[0] + velocity_prev[0]);
    distance[1] = distance_prev[1] + MULTIPLIER * (velocity[1] + velocity_prev[1]);
    distance[2] = distance_prev[2] + MULTIPLIER * (velocity[2] + velocity_prev[2]);

    //Spremanje prethodnih rezultata
    results_prev[0] = results[0];
    results_prev[1] = results[1];
    results_prev[2] = results[2];

    velocity_prev[0] = velocity[0];
    velocity_prev[1] = velocity[1];
    velocity_prev[2] = velocity[2];

    distance_prev[0] = distance[0];
    distance_prev[1] = distance[1];
    distance_prev[2] = distance[2];

    //Broj ciklusa na kraju interrupt handler-a
    end_time = DWT->CYCCNT;
    //Protekli broj ciklusa
    exec_time = end_time - start_time;
    //Suma broja ciklusa
    avg_cycles += exec_time;
}

/*
 * Timer32 odbrojava zadano vrijeme i kada brojac dostigne nulu ovaj handler se poziva
 * Onemogucavaju se prekidi, zaustavlja se ADC14 modul i timer
 */
void T32_INT2_IRQHandler() {
    __disable_interrupt();
    //Racunaje prosjecnog broja ciklusa provedenih unutar interrupt handler-a
    avg_cycles /= broj_prekida;

    //LED signalizira kraj eksperimenta
    GPIO_setOutputLowOnPin(GPIO_PORT_P2, GPIO_PIN4);
    GPIO_setOutputHighOnPin(GPIO_PORT_P2, GPIO_PIN6);


    //Onemogucavanje konverzija, ADC14 prekida i ADC14 modula
    MAP_ADC14_disableConversion();
    MAP_ADC14_disableInterrupt(INT_ADC14);
    MAP_ADC14_disableModule();
    //Ciscenje zastavice za Timer32 interrupt
    Timer32_clearInterruptFlag(TIMER32_1_BASE);
    //Onemogucavanje prekida za Timer32
    Timer32_disableInterrupt(TIMER32_1_BASE);
    //Zaustavljanje Timer32
    MAP_Timer_A_stopTimer(TIMER_A0_BASE);
    __enable_interrupt();
}
