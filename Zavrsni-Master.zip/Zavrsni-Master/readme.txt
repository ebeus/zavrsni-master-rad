Za pokretanje projekta potrebno je instalirati MSP432-SDK
Korištena verzija u projektu je bila 2_40
